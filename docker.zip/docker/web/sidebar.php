        <div class="sidebar">
		
		<div class="block">
			<h2>Carros em percurso</h2>
			<ul class="block_mais">
				<li><strong>Doblo</strong> - Placa: NIX1970</li>
				<li><strong>Kombi</strong> - Placa: GPL1980</li>
				<li class="final"><strong>Palio</strong> - Placa: GNU1997</li>
			</ul>
		<div class="block">
			<h3>Desenvolvido por:</h3>
                       <a href=# title="Allsafe Cybersecurity"><img src="images/logo_asf.png" alt="Allsafe Cybersecurity" /></a>
		</div>
		</div>
	</div>
